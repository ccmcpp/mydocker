// Copyright 2017 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package p

/*
static int transform(int x) { return x; }
*/
import "C"

func F() {
	var x rune = '✈'
	var _ rune = C.transform(x) // ERROR HERE: C\.int
}
